let h1Texto = document.querySelector("#h1Texto");
let inputTexto = document.querySelector("#inputTexto");
let btnTrocaTexto = document.querySelector("#btnTrocaTexto");

function trocarTexto(){
    //Retornando o Valor Digitado no campo--
    let textoDigitado = inputTexto.value;

    //Alterando o texto do elemento h1--
    h1Texto.textContent = textoDigitado;
}

btnTrocaTexto.onclick = function(){
    trocarTexto();
}