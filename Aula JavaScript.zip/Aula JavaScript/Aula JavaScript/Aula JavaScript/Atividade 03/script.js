let altura = document.querySelector("#altura");
let base = document.querySelector("#base");
let btn_calculo_terreno = document.querySelector("#btn_calculo_terreno");
let area_total = document.querySelector("#area_total");

function calcular_area_terreno(){
    let altura1 = Number(altura.value);
    let base1 = Number(base.value);
    let area_calculo = altura1 * base1;

    area_total.innerHTML = area_calculo + ' m² ';
}

btn_calculo_terreno.onclick = function(){
    calcular_area_terreno();
}

// haras

let cavalos_comprados = document.querySelector("#cavalos_comprados");
let btn_calculo_haras = document.querySelector("#btn_calculo_haras");
let ferraduras_a_comprar = document.querySelector("#ferraduras_a_comprar");

function calcular_ferraduras(){
    let ferradura = 4
    let cavalos = Number(cavalos_comprados.value);
    let ferraduras_totais = ferradura * cavalos;

    ferraduras_a_comprar.innerHTML = 'Você precisa de: ' + ferraduras_totais + ' Ferraduras para equipar ' + cavalos + ' Cavalos.';
}

btn_calculo_haras.onclick = function(){
    calcular_ferraduras();
}

// hotpao

let pao = document.querySelector("#pao");
let broa = document.querySelector("#broa");
let btn_calculo_vendas = document.querySelector("#btn_calculo_vendas");
let lucros = document.querySelector("#lucros");

function calcular_paes(){
    let valor_pao = 0.12;
    let valor_broa = 1.50;
    let poupanca = 0.10;

    let quantidade_pao_vendidos = Number(pao.value);
    let quantidade_broa_vendidos = Number(broa.value);

    let vendas_dia_pao = valor_pao * quantidade_pao_vendidos;
    let vendas_dia_broa = valor_broa * quantidade_broa_vendidos;
    let vendas_totais_dia = vendas_dia_broa + vendas_dia_pao;

    let calculo_poupanca = vendas_totais_dia * poupanca;
    
    
    lucros.innerHTML = 'Vendas Totais do Dia: R$ ' + vendas_totais_dia.toFixed(2) + '<br>' + 
    'Saldo para Aplicação: R$ ' + calculo_poupanca.toFixed(2) + '<br>' +
    'Vendeu: ' + quantidade_pao_vendidos + ' Pães e ' + quantidade_broa_vendidos + ' Broas';
}

btn_calculo_vendas.onclick = function(){
    calcular_paes();
}

// dias de vida

let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let btn_calculo_dias = document.querySelector("#btn_calculo_dias");
let resposta = document.querySelector("#resposta");

function calular_anos(){
    let nome_input = nome.value;
    let idade_input = Number(idade.value);
    let anos = 365;

    let dias_de_vida = idade_input * anos;

    resposta.innerHTML = nome_input + ', Você tem ' + Number(dias_de_vida) + ' Dias de Vida!!!'
}

btn_calculo_dias.onclick = function(){
    calular_anos();
}

// Abastecimento

let valor_gasolina = document.querySelector("#valor_gasolina");
let valor_litro = document.querySelector("#valor_litro");
let btn_gasolina = document.querySelector("#btn_gasolina");
let litros = document.querySelector("#litros");

function abastecimento(){
    let valor1 = Number(valor_gasolina.value);
    let valor2 = Number(valor_litro.value);
    let calculos;
        if (valor2 <= 0){
            calculos = 0;
        } else {
            calculos = valor1 / valor2;
        }
    litros.innerHTML = 'Com R$ ' + valor1.toFixed(2) + ', você abastece ' + calculos.toFixed(2) + ' litros';

}
btn_gasolina.onclick = function(){
    abastecimento();
}

// Restaurante Bem-Bão

let prato_kg = document.querySelector("#prato_kg");
let btn_kg = document.querySelector("#btn_kg");
let valor_a_pagar_kg = document.querySelector("#valor_a_pagar_kg");

function peso_kg(){
    let tara_prato = 0.800;
    let valor_kg = 12;
    let peso_prato = Number(prato_kg.value) - tara_prato;

    let valor_peso = peso_prato * valor_kg;
    if (peso_prato < 0){
        valor_peso = 0;
    }
    valor_a_pagar_kg.innerHTML = 'TARA: ' + tara_prato.toFixed(3) + '<br>' +
                                'PESO: ' + peso_prato.toFixed(3) + '(T)<br>' +
                                'R$/kg: ' + valor_kg.toFixed(2) + '(L)<br><br>' +
                                'TOTAL R$ ' + valor_peso.toFixed(2)
}

btn_kg.onclick = function(){
    peso_kg();
}

// Dias se passou 

let dia_inicial = document.querySelector("#dia_inicial");
let mes_inicial = document.querySelector("#mes_inicial");
let dias_que_passam = document.querySelector("#dias_que_passam");
let btn_dias_que_passam = document.querySelector("#btn_dias_que_passam");

function dias_passados(){
    let dia = Number(dia_inicial.value);
    let mes = Number(mes_inicial.value);

    if (mes <= 0) {
    mes = 1;
    }
       
    
    let calc_dias_mes = (mes - 1) * 30 + dia;   
    
    dias_que_passam.innerHTML = 'Se passaram ' + calc_dias_mes + 
    ' dias desde o começo do Ano!'

}

btn_dias_que_passam.onclick = function(){
    dias_passados();
}

// Loja de Camisas

let btn_mais_p = document.querySelector("#btn_mais_p");
let btn_menos_p = document.querySelector("#btn_menos_p");

let btn_mais_m = document.querySelector("#btn_mais_m");
let btn_menos_m = document.querySelector("#btn_menos_m")

let btn_mais_g = document.querySelector("#btn_mais_g");
let btn_menos_g = document.querySelector("#btn_menos_g");

let btn_calc_camisas = document.querySelector("#btn_calc_camisas");

let camisa_p = document.querySelector("#camisa_p");
let camisa_m = document.querySelector("#camisa_m");
let camisa_g = document.querySelector("#camisa_g");

let resultado_vendas_camisas = document.querySelector("#resultado_vendas_camisas");

btn_mais_p.onclick = function(){
    camisa_p.value = Number(camisa_p.value) + 1;
}
btn_menos_p.onclick = function(){
    camisa_p.value = Number(camisa_p.value) - 1;
    if(camisa_p.value <= 0){
        camisa_p.value = 0;
    }
}
btn_mais_m.onclick = function(){
    camisa_m.value = Number(camisa_m.value) + 1;
}
btn_menos_m.onclick = function(){
    camisa_m.value = Number(camisa_m.value) - 1;
    if(camisa_m.value <= 0){
        camisa_m.value = 0;
    }
}
btn_mais_g.onclick = function(){
    camisa_g.value = Number(camisa_g.value) + 1;
}
btn_menos_g.onclick = function(){
    camisa_g.value = Number(camisa_g.value) - 1;
    if(camisa_g.value <= 0){
        camisa_g.value = 0;
    }
}

function vender_camisas(){

    resultado_vendas_camisas.innerHTML = '';

    let qtd_p = Number(camisa_p.value);
    let qtd_m = Number(camisa_m.value);
    let qtd_g = Number(camisa_g.value);

    if(camisa_p.value < 2){
        resultado_vendas_camisas.innerHTML = camisa_p.value + ' Camisa Pequena' + '<br>' +
                                            'Total de R$ ' + (qtd_p * 10).toFixed(2) + '<br>';
    }else{
        resultado_vendas_camisas.innerHTML = camisa_p.value + ' Camisas Pequenas' + '<br>' +
                                            'Total de R$ ' + (qtd_p * 10).toFixed(2) + '<br>';
    }

    if(camisa_m.value < 2){
        resultado_vendas_camisas.innerHTML += '<br>' + camisa_m.value + ' Camisa Média' + '<br>' +
                                            'Total de R$ ' + (qtd_m * 12).toFixed(2) + '<br>';
    }else{
        resultado_vendas_camisas.innerHTML += '<br>' + camisa_m.value + ' Camisas Médias' + '<br>' +
                                            'Total de R$ ' + (qtd_m * 12).toFixed(2) + '<br>';
    }

    if(camisa_g.value < 2){
        resultado_vendas_camisas.innerHTML += '<br>' + camisa_g.value + ' Camisa Grande' + '<br>' +
                                            'Total de R$ ' + (qtd_g * 15).toFixed(2) + '<br>';
    }else {
        resultado_vendas_camisas.innerHTML += '<br>' + camisa_g.value + ' Camisas Grandes' + '<br>' +
                                            'Total de R$ ' + (qtd_g * 15).toFixed(2) + '<br>';
    }

    let total_compar = (qtd_p * 10) + (qtd_m * 12) + (qtd_g * 15);

    if(total_compar == 0){
        resultado_vendas_camisas.innerHTML += '<br>' + 'Pedido Vazio';
    }else {
        resultado_vendas_camisas.innerHTML += '<br>' + 'TOTAL(R$): ' + total_compar.toFixed(2);
    }
}


btn_calc_camisas.onclick = function(){
    vender_camisas();
}