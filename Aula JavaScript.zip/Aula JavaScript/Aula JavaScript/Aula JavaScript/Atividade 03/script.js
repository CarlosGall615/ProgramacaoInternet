let altura = document.querySelector("#altura");
let base = document.querySelector("#base");
let btn_calculo_terreno = document.querySelector("#btn_calculo_terreno");
let area_total = document.querySelector("#area_total");

function calcular_area_terreno(){
    let altura1 = Number(altura.value);
    let base1 = Number(base.value);
    let area_calculo = altura1 * base1;

    area_total.innerHTML = area_calculo + ' m² ';
}

btn_calculo_terreno.onclick = function(){
    calcular_area_terreno();
}

// haras

let cavalos_comprados = document.querySelector("#cavalos_comprados");
let btn_calculo_haras = document.querySelector("#btn_calculo_haras");
let ferraduras_a_comprar = document.querySelector("#ferraduras_a_comprar");

function calcular_ferraduras(){
    let ferradura = 4
    let cavalos = Number(cavalos_comprados.value);
    let ferraduras_totais = ferradura * cavalos;

    ferraduras_a_comprar.innerHTML = 'Você precisa de: ' + ferraduras_totais + ' Ferraduras para equipar ' + cavalos + ' Cavalos.';
}

btn_calculo_haras.onclick = function(){
    calcular_ferraduras();
}

// hotpao

let pao = document.querySelector("#pao");
let broa = document.querySelector("#broa");
let btn_calculo_vendas = document.querySelector("#btn_calculo_vendas");
let lucros = document.querySelector("#lucros");

function calcular_paes_e_lucros(){
    let valor_pao = 0.12;
    let valor_broa = 1.50;
    let poupança = 10 / 100;

    let quantidade_pao_vendidos = Number(pao.value);
    let quantidade_broa_vendidos = Number(broa.value);

    let vendas_dia_pao = valor_pao * quantidade_pao_vendidos;
    let vendas_dia_broa = valor_broa * quantidade_broa_vendidos;
    let vendas_totais_dia = vendas_dia_broa + vendas_dia_pao;

    
    lucros.innerHTML = vendas_totais_dia
}
btn_calculo_vendas.onclick = function(){
    calcular_paes_e_lucros();
}