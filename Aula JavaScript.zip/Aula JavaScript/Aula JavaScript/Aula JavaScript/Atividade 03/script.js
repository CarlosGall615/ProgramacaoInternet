let altura = document.querySelector("#altura");
let base = document.querySelector("#base");
let btn_calculo_terreno = document.querySelector("#btn_calculo_terreno");
let area_total = document.querySelector("#area_total");

function calcular_area_terreno(){
    let altura1 = Number(altura.value);
    let base1 = Number(base.value);
    let area_calculo = altura1 * base1;

    area_total.innerHTML = area_calculo + ' m² ';
}

btn_calculo_terreno.onclick = function(){
    calcular_area_terreno();
}

// haras

let cavalos_comprados = document.querySelector("#cavalos_comprados");
let btn_calculo_haras = document.querySelector("#btn_calculo_haras");
let ferraduras_a_comprar = document.querySelector("#ferraduras_a_comprar");

function calcular_ferraduras(){
    let ferradura = 4
    let cavalos = Number(cavalos_comprados.value);
    let ferraduras_totais = ferradura * cavalos;

    ferraduras_a_comprar.innerHTML = 'Você precisa de: ' + ferraduras_totais + ' Ferraduras para equipar ' + cavalos + ' Cavalos.';
}

btn_calculo_haras.onclick = function(){
    calcular_ferraduras();
}

// hotpao

let pao = document.querySelector("#pao");
let broa = document.querySelector("#broa");
let btn_calculo_vendas = document.querySelector("#btn_calculo_vendas");
let lucros = document.querySelector("#lucros");

function calcular_paes(){
    let valor_pao = 0.12;
    let valor_broa = 1.50;
    let poupanca = 0.10;

    let quantidade_pao_vendidos = Number(pao.value);
    let quantidade_broa_vendidos = Number(broa.value);

    let vendas_dia_pao = valor_pao * quantidade_pao_vendidos;
    let vendas_dia_broa = valor_broa * quantidade_broa_vendidos;
    let vendas_totais_dia = vendas_dia_broa + vendas_dia_pao;

    let calculo_poupanca = vendas_totais_dia * poupanca;
    
    lucros.innerHTML = 'Vendas Totais do Dia: R$ ' + vendas_totais_dia.toFixed(2) + '<br>' + 
    'Saldo para Aplicação: R$ ' + calculo_poupanca.toFixed(2) + '<br>' +
    'Vendeu: ' + quantidade_pao_vendidos + ' Pães e ' + quantidade_broa_vendidos + ' Broas';
}

btn_calculo_vendas.onclick = function(){
    calcular_paes();
}

// dias de vida

let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let btn_calculo_dias = document.querySelector("#btn_calculo_dias");
let resposta = document.querySelector("#resposta");

function calular_anos(){
    let nome_input = nome.value;
    let idade_input = Number(idade.value);
    let anos = 365;

    let dias_de_vida = idade_input * anos;

    resposta.innerHTML = nome_input + ', Você tem ' + Number(dias_de_vida) + ' Dias de Vida!!!'
}

btn_calculo_dias.onclick = function(){
    calular_anos();
}

// Abastecimento

let valor_gasolina = document.querySelector("#valor_gasolina");
let valor_litro = document.querySelector("#valor_litro");
let btn_gasolina = document.querySelector("#btn_gasolina");
let litros = document.querySelector("#litros");

function abastecimento(){
    let valor1 = Number(valor_gasolina.value);
    let valor2 = Number(valor_litro.value);
    let calculos;
        if (valor2 <= 0){
            calculos = 0;
        } else {
            calculos = valor1 / valor2;
        }
    litros.innerHTML = 'Com R$ ' + valor1.toFixed(2) + ', você abastece ' + calculos.toFixed(2) + ' litros';

}
btn_gasolina.onclick = function(){
    abastecimento();
}