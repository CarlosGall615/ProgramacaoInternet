let dolar_calc = document.querySelector("#dolar_calc");
let result_dolar = document.querySelector("#result_dolar");

let first_button = document.querySelector("#first_button");
let second_button = document.querySelector("#second_button");
let third_button = document.querySelector("#third_button");
let fourth_button = document.querySelector("#fourth_button");

function calcular_dolar(taxa){
   
    let dolar = Number(dolar_calc.value) * taxa + Number(dolar_calc.value);
      
    result_dolar.textContent = dolar.toFixed(2)
}

first_button.onclick = function(){
    calcular_dolar(0.01);
}
second_button.onclick = function(){
    calcular_dolar(0.02);
}
third_button.onclick = function(){
    calcular_dolar(0.05);
}
fourth_button.onclick = function(){
    calcular_dolar(0.10);
}

// Atividade 02

let people_numbers = document.querySelector("#people_numbers");
let calc_omeletes = document.querySelector("#calc_omeletes");
let result_omelete = document.querySelector("#result_omelete");

function receita_omelete(){
    let ovos = 2;
    let queijo = 50;

    let qtd_ovos = Number(people_numbers.value) * ovos;
    let qtd_queijo = Number(people_numbers.value) * queijo;

    let receita = "Você Precisa de: " + qtd_ovos + ' Ovos ';
    let receita2 = qtd_queijo + 'g de Queijo ';

    result_omelete.textContent = receita + ' e ' + receita2
}

calc_omeletes.onclick = function(){
    receita_omelete();
}

// Atividade 03

let n1 = document.querySelector("#n1");
let n2 = document.querySelector("#n2");

let calc_n = document.querySelector("#calc_n");

let soma = document.querySelector("#soma");
let subtracao = document.querySelector("#subtracao");
let multiplicacao = document.querySelector("#multiplicacao");
let divisao = document.querySelector("#divisao");

function calculos_matematicos_basicos(){
    let input1 = Number(n1.value);
    let input2 = Number(n2.value);

    let somar = 'A soma é: ' + (input1 + input2);
    let subtrair = 'A subtração é: ' + (input1 - input2);
    let multiplicar = 'A multiplicação é: ' + input1 * input2;
    let dividir;
    if (input2 == 0) {
        dividir = 'A divisão é: 0 ';
    }else {
        dividir = 'A divisão é: ' + (input1 / input2).toFixed(2);
    }

    soma.textContent = somar
    subtracao.textContent = subtrair
    multiplicacao.textContent = multiplicar
    divisao.textContent = dividir

}

calc_n.onclick = function(){
    calculos_matematicos_basicos();
}

// Atividade 04

let sabor1 = document.querySelector("#sabor1");
let sabor2 = document.querySelector("#sabor2");
let sabor3 = document.querySelector("#sabor3");
let sabor4 = document.querySelector("#sabor4");
let sabor5 = document.querySelector("#sabor5");
let sabor6 = document.querySelector("#sabor6");

let sim = document.querySelector("#sim");
let nao = document.querySelector("#nao");

let qtd_refri = document.querySelector("#qtd_refri");
let btn_calc = document.querySelector("#btn_calc");

let sabores_pizza = document.querySelector("#sabores_pizza"); 
let valor_a_pagar = document.querySelector("#valor_a_pagar");
let refrig = document.querySelector("#refrig");

function pizzas_select(){
    let lista_pizzas = [];
    let valor_sabor = 0;
    let valor_refri = 7;
    let refri_total = valor_refri * Number(qtd_refri.value);

    refrig.textContent = "Refrigerantes: " + Number(qtd_refri.value) 
    
    

    if (document.querySelector("#sabor1").checked) {
        lista_pizzas.push("Strogonoff de Carne");
        valor_sabor += 12;
    }
    if (document.querySelector("#sabor2").checked) {
        lista_pizzas.push("Strogonoff de Frango");
        valor_sabor += 12;
    }
    if (document.querySelector("#sabor3").checked) {
        lista_pizzas.push("Baiana");
        valor_sabor += 12;
    }    
    if (document.querySelector("#sabor4").checked) {
        lista_pizzas.push("Lombo Canadense");
        valor_sabor += 12;
    }
    if (document.querySelector("#sabor5").checked) {
        lista_pizzas.push("Panceta com Melado");
        valor_sabor += 12;
    }
    if (document.querySelector("#sabor6").checked) {
        lista_pizzas.push("Chocolate");
        valor_sabor += 12;
    }

    
    if (lista_pizzas.length > 4) {
        sabores_pizza.textContent = "Escolha apenas 04 Sabores";
    } else if (lista_pizzas.length > 0) {
        sabores_pizza.textContent = "Seu Pedido é: " + lista_pizzas.join(", ");
    } else {
        sabores_pizza.textContent = "Pedido Vazio";
    }
    
    valor_a_pagar.textContent = "Total R$ " + (valor_sabor + refri_total).toFixed(2);

}

btn_calc.onclick = function(){
    pizzas_select();
}

