let first_number = document.querySelector("#first_number");
let second_number = document.querySelector("#second_number");
let btnSomar = document.querySelector("#btnSomar");
let result = document.querySelector("#result");

function soma(){
    let resultado_soma = Number(first_number.value) + Number(second_number.value);

    result.textContent = resultado_soma
}

btnSomar.onclick = function(){
    soma();
}

//Atividade 02

let valor_pgt = document.querySelector("#valor_pgt");
let valor_product = document.querySelector("#valor_product");
let btnTroco = document.querySelector("#btnTroco");
let troco = document.querySelector("#troco");

function calular_produto(){
    let pagamento_produto = Number(valor_pgt.value) - Number(valor_product.value);

    troco.textContent = ' Seu Troco é de: ' + pagamento_produto.toFixed(2)
}

btnTroco.onclick = function(){
    calular_produto();
}

//Atividade 03

let kg_price = document.querySelector("#kg_price");
let kg_qtd = document.querySelector("#kg_qtd");
let kg_valor_pgt = document.querySelector("#kg_valor_pgt");
let valor_a_pagar = document.querySelector("#valor_a_pagar");

function pesar(){
    let etiqueta = Number(kg_price.value) * Number(kg_qtd.value);

    valor_a_pagar.textContent = etiqueta.toFixed(2)
}

kg_valor_pgt.onclick = function(){
    pesar();
}

//Atividade 04

let saldo_inicial = document.querySelector("#saldo_inicial");
let saldo_final_reajustado = document.querySelector("#saldo_final_reajustado");

let calculo_saldo = document.querySelector("#calculo_saldo");

function reajuste_salario(taxa){
    let percent = Number(saldo_inicial.value) * taxa + Number(saldo_inicial.value);
    
    saldo_final_reajustado.textContent = percent.toFixed(2)
}

calculo_saldo.onclick = function(){
    reajuste_salario(0.01);
}

// Atividade 05

let first_note = document.querySelector("#first_note");
let second_note = document.querySelector("#second_note");
let third_note = document.querySelector("#third_note");

let media_note = document.querySelector("#media_note");
let media_ponderada = document.querySelector("#media_ponderada");
let soma_media = document.querySelector("#soma_media");
let media_for_media = document.querySelector("#media_for_media");

let results = document.querySelector("#results");

function media_calculos(){
    let nt1 = Number(first_note.value);
    let nt2 = Number(second_note.value);
    let nt3 = Number(third_note.value);

    let calc_media = (nt1 + nt2 + nt3) / 3;
    
    results.textContent = calc_media.toFixed(2)
}

media_note.onclick = function(){
    media_calculos(); 
}

function media_pond(){
    let nt1 = Number(first_note.value);
    let nt2 = Number(second_note.value);
    let nt3 = Number(third_note.value);
    
    let p1 = 2;
    let p2 = 3;
    let p3 = 5;

    let calc_pond = (nt1 * p1 + nt2 * p2 + nt3 * p3) / (p1 + p2 + p3);

    results.textContent = calc_pond.toFixed(2)
}

media_ponderada.onclick = function(){
    media_pond();
}

function soma_das_medias(){
    let nt1 = Number(first_note.value);
    let nt2 = Number(second_note.value);
    let nt3 = Number(third_note.value);

    let calc_media = (nt1 + nt2 + nt3) / 3;

    let p1 = 2;
    let p2 = 3;
    let p3 = 5;

    let calc_pond = (nt1 * p1 + nt2 * p2 + nt3 * p3) / (p1 + p2 + p3);


    let somatorio_das_medias = calc_media + calc_pond; 

    results.textContent = somatorio_das_medias.toFixed(2)
}

soma_media.onclick = function(){
    soma_das_medias();
}

function media_das_medias(){
    let nt1 = Number(first_note.value);
    let nt2 = Number(second_note.value);
    let nt3 = Number(third_note.value);

    let calc_media = (nt1 + nt2 + nt3) / 3;

    let p1 = 2;
    let p2 = 3;
    let p3 = 5;

    let calc_pond = (nt1 * p1 + nt2 * p2 + nt3 * p3) / (p1 + p2 + p3);

    let media_para_media = (calc_media + calc_pond) / 2;

    results.textContent = media_para_media.toFixed(2)
}

media_for_media.onclick = function(){
    media_das_medias();
}

// Atividade 06

let num1 = document.querySelector("#num1");
let num2 = document.querySelector("#num2");
let calc_nums = document.querySelector("#calc_nums");

let nums_comp = document.querySelector("#nums_comp");

function calcular_maior(){

    let number1 = Number(num1.value);
    let number2 = Number(num2.value);
    if (number1 >= number2) {
        nums_comp.textContent = ' O Número Maior é: ' + number1;
    } else {
        nums_comp.textContent = ' O Número Maior é: ' + number2
    }

}

calc_nums.onclick = function(){
    calcular_maior();
}

// Atividade 07

let n1 = document.querySelector("#n1");
let n2 = document.querySelector("#n2");
let n3 = document.querySelector("#n3");
let n4 = document.querySelector("#n4");

let calc_nums2 = document.querySelector("#calc_nums2");

let nums_comp2 = document.querySelector("#nums_comp2");

function calc_menor(){
    let numb1 = Number(n1.value);
    let numb2 = Number(n2.value);
    let numb3 = Number(n3.value);
    let numb4 = Number(n4.value);

    if (numb1 <= numb2 && numb1 <= numb3 && numb1 <= numb4) {
        nums_comp2.textContent = 'O Primeiro Número é o Menor: ' + numb1;
    } else if (numb2 <= numb1 && numb2 <= numb3 && numb2 <= numb4) {
        nums_comp2.textContent = 'O Segundo Número é o Menor: ' + numb2;
    } else if (numb3 <= numb1 && numb3 <= numb2 && numb3 <= numb4) {
        nums_comp2.textContent = 'O Terceiro Número é o Menor: ' + numb3;
    } else {
        nums_comp2.textContent = 'O Quarto Número é Menor: ' + numb4;
    }
}

calc_nums2.onclick = function(){
    calc_menor();
}

// Atividade 08

let nb1 = document.querySelector("#nb1");


let calc_nb = document.querySelector("#calc_nb");
let nums_nb = document.querySelector("#nums_nb");

function par_ou_impar(){
    let campo1 = Number(nb1.value);
    
    if (campo1 % 2 == 0) {
        nums_nb.textContent = 'O Número ' + campo1 + ' é Par';
    } else {
        nums_nb.textContent = 'O Número ' + campo1 + ' é Ímpar';
    }
}

calc_nb.onclick = function(){
    par_ou_impar();
}