let first_number = document.querySelector("#first_number");
let second_number = document.querySelector("#second_number");
let btnSomar = document.querySelector("#btnSomar");
let result = document.querySelector("#result");

function soma(){
    let resultado_soma = Number(first_number.value) + Number(second_number.value);

    result.textContent = resultado_soma
}

btnSomar.onclick = function(){
    soma();
}

//Atividade 02

let valor_pgt = document.querySelector("#valor_pgt");
let valor_product = document.querySelector("#valor_product");
let btnTroco = document.querySelector("#btnTroco");
let troco = document.querySelector("#troco");

function calular_produto(){
    let pagamento_produto = Number(valor_pgt.value) - Number(valor_product.value);

    troco.textContent = pagamento_produto
}

btnTroco.onclick = function(){
    calular_produto();
}

//Atividade 03

let kg_price = document.querySelector("#kg_price");
let kg_qtd = document.querySelector("#kg_qtd");
let kg_valor_pgt = document.querySelector("#kg_valor_pgt");
let valor_a_pagar = document.querySelector("#valor_a_pagar");

function pesar(){
    let etiqueta = Number(kg_price.value) * Number(kg_qtd.value);

    valor_a_pagar.textContent = etiqueta
}

kg_valor_pgt.onclick = function(){
    pesar();
}

//Atividade 04

let saldo_inicial = document.querySelector("#saldo_inicial");
let saldo_final_reajustado = document.querySelector("#saldo_final_reajustado");

let calculo_saldo = document.querySelector("#calculo_saldo");

function reajuste_salario(taxa){
    let percent = Number(saldo_inicial.value) * taxa + Number(saldo_inicial.value);
    
    saldo_final_reajustado.textContent = percent
}

calculo_saldo.onclick = function(){
    reajuste_salario(0.01);
}

// Atividade 05

let first_note = document.querySelector("#first_note");
let second_note = document.querySelector("#second_note");
let third_note = document.querySelector("#third_note");

let media_note = document.querySelector("#media_note");
let media_ponderada = document.querySelector("#media_ponderada");
let soma_media = document.querySelector("#soma_media");
let media_for_media = document.querySelector("#media_for_media");

let results = document.querySelector("#results");

function media_calculos(){
    let calc1 = Number(first_note.value) + Number(second_note.value) + Number(third_note.value);
    let calc2 = calc1 / 3
    results.textContent = calc2
}

media_note.onclick = function(){
    media_calculos(); 
}

