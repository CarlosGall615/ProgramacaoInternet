let first_number = document.querySelector("#first_number");
let second_number = document.querySelector("#second_number");
let btnSomar = document.querySelector("#btnSomar");
let result = document.querySelector("#result");

function soma(){
    let resultado_soma = Number(first_number.value) + Number(second_number.value);

    result.textContent = resultado_soma
}

btnSomar.onclick = function(){
    soma();
}

//Atividade 02

let valor_pgt = document.querySelector("#valor_pgt");
let valor_product = document.querySelector("#valor_product");
let btnTroco = document.querySelector("#btnTroco");
let troco = document.querySelector("#troco");

function calular_produto(){
    let pagamento_produto = Number(valor_pgt.value) - Number(valor_product.value);

    troco.textContent = pagamento_produto
}

btnTroco.onclick = function(){
    calular_produto();
}

//Atividade 03

let kg_price = document.querySelector("#kg_price");
let kg_qtd = document.querySelector("#kg_qtd");
let kg_valor_pgt = document.querySelector("#kg_valor_pgt");
let valor_a_pagar = document.querySelector("#valor_a_pagar");

function pesar(){
    let etiqueta = Number(kg_price.value) * Number(kg_qtd.value);

    valor_a_pagar.textContent = etiqueta
}

kg_valor_pgt.onclick = function(){
    pesar();
}

//Atividade 04

let saldo_inicial = document.querySelector("#saldo_inicial");
let reajuste_percet = document.querySelector("#reajuste_percet");
let calculo_saldo = document.querySelector("#calculo_saldo");
let saldo_final_reajustado = document.querySelector("#saldo_final_reajustado");

function reajuste_salario(){
    let percent = Number(reajuste_percet) / 100;
    console.log(percent) * Number(saldo_inicial);

    saldo_final_reajustado.textContent = 
}

calculo_saldo.onclick = function(){
    reajuste_salario();
}