let dolar_calc = document.querySelector("#dolar_calc");
let result_dolar = document.querySelector("#result_dolar");

let first_button = document.querySelector("#first_button");
let second_button = document.querySelector("#second_button");
let third_button = document.querySelector("#third_button");
let fourth_button = document.querySelector("#fourth_button");

function calcular_dolar(taxa){
   
    let dolar = Number(dolar_calc.value) * taxa + Number(dolar_calc.value);
      
    result_dolar.textContent = dolar
}

first_button.onclick = function(){
    calcular_dolar(0.01);
}
second_button.onclick = function(){
    calcular_dolar(0.02);
}
third_button.onclick = function(){
    calcular_dolar(0.05);
}
fourth_button.onclick = function(){
    calcular_dolar(0.10);
}

// Atividade 02

