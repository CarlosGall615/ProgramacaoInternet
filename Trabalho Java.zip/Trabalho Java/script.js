// Atividade 01 Triangulos

let tri_x = document.querySelector("#tri_x");
let tri_y = document.querySelector("#tri_y");
let tri_z = document.querySelector("#tri_z");

let btn_verificar = document.querySelector("#btn_verificar");

let result_triangulos = document.querySelector("#result_triangulos");

function calcular_triangulos(){
    let x = Number(tri_x.value);
    let y = Number(tri_y.value);
    let z = Number(tri_z.value);

    let t1 = x + y > z;
    let t2 = x + z > y;
    let t3 = y + z > x;

    if(t1 && t2 && t3){
        if(x == y && y == z){
        result_triangulos.innerHTML = 'Esse triângulo é <b>"Equilátero"</b> ';
            }else if (x == y || x == z || y == z){
        result_triangulos.innerHTML = 'O triângulo é <b>"Isósceles"</b> ';
            }else {
        result_triangulos.innerHTML = 'Seu triângulo é <b>"Escaleno"</b>';
            }
    }else {
        result_triangulos.innerHTML = 'Os valores <b>"não formam um triângulo"</b>.';
    }   
}

btn_verificar.onclick = function(){
    calcular_triangulos();
    limpar_campos();
}

// Atividade 02 Calculadora IMC

let peso = document.querySelector("#peso");
let altura = document.querySelector("#altura");

let btn_verificar_imc = document.querySelector("#btn_verificar_imc");

let result_imc = document.querySelector("#result_imc");

function calcular_imc(){

    let peso_1 = Number(peso.value);
    let altura_1 = Number(altura.value);

    let imc = peso_1 / (altura_1 ** 2);

    if(imc < 18.5){
        result_imc.innerHTML = imc.toFixed(2) + ' Abaixo do Peso'
    }else if (imc > 18.5 && imc < 24.9){
        result_imc.innerHTML = imc.toFixed(2) + " Peso Normal"
    }else if (imc > 25 && imc < 29.9){
        result_imc.innerHTML = imc.toFixed(2) + " Sobrepeso"
    }else if (imc > 30 && imc < 34.9){
        result_imc.innerHTML = imc.toFixed(2) + " Obesidade grau 1"
    }else if (imc > 35 && imc < 39.9){
        result_imc.innerHTML = imc.toFixed(2) + " Obesidade grau 2"
    }else if (imc > 40){
        result_imc.innerHTML = imc.toFixed(2) + " Obesidade grau 3"
    }else {
        result_imc.innerHTML = "Insira os Dados Corretamente"
    }
}

btn_verificar_imc.onclick = function(){
    calcular_imc();
    limpar_campos();
}

// Atividade 03 Calculadora de Imposto

let ano_carro = document.querySelector("#ano_carro");
let fipe_carro = document.querySelector("#fipe_carro");

let btn_verificar_imposto = document.querySelector("#btn_verificar_imposto");

let result_imposto = document.querySelector("#result_imposto");

function calcular_imposto(){

    let fipe_carro_1 = Number(fipe_carro.value);
    let ano_carro_1 = Number(ano_carro.value);
    if(fipe_carro.value === '' || ano_carro.value === ''){
        result_imposto.innerHTML = "Dados Inválidos ";
        return;
    }

    let taxa_detran = (1 / 100);
    let taxa_detran_2 = (1.5 / 100);
    let ano = 1990;

    let imposto = fipe_carro_1 * taxa_detran;
    if(ano_carro_1 > ano){
        imposto = fipe_carro_1 * taxa_detran_2;
    }
    result_imposto.innerHTML = "Você deve pagar<br> R$ " + imposto.toFixed(2) + 
    ' de Imposto ao DETRAN.';
}
btn_verificar_imposto.onclick = function(){
    calcular_imposto();
    limpar_campos();
}

// Atividade 04 Calculadora de Reajuste Salarial

let salario_base = document.querySelector("#salario_base");
let cargo = document.querySelector("#cargo");

let btn_verificar_salario = document.querySelector("#btn_verificar_salario");

let result_salario = document.querySelector("#result_salario");

function calcular_reajuste_salario(){
    let salario_atual = Number(salario_base.value);
    let cargo = document.querySelector("#cargo").value;

    let gerente_reajuste = salario_atual * (10 / 100);
    let gerente_salario_final = gerente_reajuste + salario_atual;

    let engenheiro_reajuste = salario_atual * (20 / 100);
    let engenheiro_salario_final = engenheiro_reajuste + salario_atual;

    let tecnico_reajuste = salario_atual * (30 / 100);
    let tecnico_salario_final = tecnico_reajuste + salario_atual;

    let outro_reajuste = salario_atual * (40 / 100);
    let outro_salario_final = outro_reajuste + salario_atual;

    if(cargo == 'Selecione o Cargo/Função' || cargo == ''){
        result_salario.innerHTML = 'Nenhum Cargo Selecionado. ';
    }else if(cargo == 'Gerente'){
        result_salario.innerHTML = "<b>Cargo:</b> " + cargo + '<br>' +
                                    "<b>Salário Atual:</b> R$ " + salario_atual.toFixed(2) + '<br>' +
                                    "<b>Valor do Reajuste:</b> R$ " + gerente_reajuste.toFixed(2) + '<br>' +
                                    "<b>Salário Reajustado:</b> R$ " + gerente_salario_final.toFixed(2);
    }else if(cargo == 'Engenheiro'){
        result_salario.innerHTML = "<b>Cargo:</b> " + cargo + '<br>' +
                                    "<b>Salário Atual:</b> R$ " + salario_atual.toFixed(2) + '<br>' +
                                    "<b>Valor do Reajuste:</b> R$ " + engenheiro_reajuste.toFixed(2) + '<br>' +
                                    "<b>Salário Reajustado:</b> R$ " + engenheiro_salario_final.toFixed(2);
    }else if(cargo === "Técnico"){
        result_salario.innerHTML = "<b>Cargo:</b> " + cargo + '<br>' +
                                    "<b>Salário Atual:</b> R$ " + salario_atual.toFixed(2) + '<br>' +
                                    "<b>Valor do Reajuste:</b> R$ " + tecnico_reajuste.toFixed(2) + '<br>' +
                                    "<b>Salário Reajustado:</b> R$ " + tecnico_salario_final.toFixed(2);
    }else {
        result_salario.innerHTML = "<b>Cargo:</b> " + cargo + '<br>' +
                                    "<b>Salário Atual:</b> R$ " + salario_atual.toFixed(2) + '<br>' +
                                    "<b>Valor do Reajuste:</b> R$ " + outro_reajuste.toFixed(2) + '<br>' +
                                     "<b>Salário Reajustado:</b> R$ " + outro_salario_final.toFixed(2);
    }
}
    
btn_verificar_salario.onclick = function(){
    calcular_reajuste_salario();
    limpar_campos();
}



function limpar_campos() {
    //atv 01
    tri_x.value = '';
    tri_y.value = '';
    tri_z.value = '';
    //atv 02
    peso.value = '';
    altura.value = '';
    //atv 03
    fipe_carro.value = '';
    ano_carro.value = '';
    //atv 04
    salario_base.value = '';
    cargo.value = '';
}